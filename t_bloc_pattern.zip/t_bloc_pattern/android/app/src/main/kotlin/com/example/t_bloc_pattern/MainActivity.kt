package com.example.t_bloc_pattern

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
